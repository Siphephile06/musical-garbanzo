from django.db import models
import datetime
from rest_framework import serializers
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    """User model representing a user in the e-commerce system.
       Fields:
            - username: Unique username for the user
            - email: Email address of the user
            - password: Password for the user account
            - group: Group to which the user belongs

         Methods:
            - __str__: Returns the username of the user
    """
    email = models.EmailField(max_length=255)
    group = models.CharField(max_length=50)

    def __str__(self):
        return self.username


class Store(models.Model):
    """Store model representing an e-commerce store.
       Fields:
              - name: Name of the store
              - location: Physical location of the store.
              Methods:
              - __str__: Returns the name of the store
    """
    name = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return self.name

    class Meta:
        permissions = [
            ("create_store", "Can create store"),
            ("update_store", "Can update store"),
            ("create_product", "Can create product"),
            ("update_product", "Can update product"),
            ("delete_product", "Can delete product"),
            ("checkout", "Can checkout"),
            ("reviews", "Can write reviews"),
        ]


class StoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Store
        fields = ['id', 'name', 'location', 'owner']


class Product(models.Model):
    """Class representing a product in the e-commerce system.
       Fields:
            - name: Name of the product
            - description: Description of the product
            - price: Price of the product
            - stock: Stock quantity available for the product
            - store: Foreign key to the Store model
            - image: Image associated with the product

        Methods:
            - __str__: Returns the name of the product
    """
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=500, default=" ",
                                   blank=True, null=True)
    price = models.DecimalField(default=0, max_digits=10,
                                decimal_places=2)
    stock = models.IntegerField(default=0, blank=True, null=True)
    store = models.ForeignKey(Store, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='uploads/products/',
                              blank=True, null=True)


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name', 'description', 'price', 'stock', 'store',
                  'image']


class Order(models.Model):
    """Class representing an order in the e-commerce system.
       Fields:
            - user: Foreign key to the User model
            - product: Foreign key to the Product model
            - address: Shipping address for the order
            - quantity: Quantity of the product ordered
            - order_date: Date when the order was placed

        Methods:
            - __str__: Returns a string representation of the order
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    address = models.CharField(max_length=255)
    quantity = models.IntegerField(default=1)
    order_date = models.DateTimeField(default=datetime.datetime.now)

    def __str__(self):
        return f"Order by {self.user.username} for {self.product.name}"


class Review(models.Model):
    """Class representing a review for a product in the e-commerce system.
       Fields:
            - user: Foreign key to the User model
            - product: Foreign key to the Product model
            - rating: Rating given by the user (1-5)
            - comment: Review comment by the user
            - created_at: Timestamp when the review was created

        Methods:
            - __str__: Returns a string representation of the review
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    rating = models.IntegerField(default=1)
    comment = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Review by {self.user.username} for {self.product.name}"


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = '__all__'


class ResetToken(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    token = models.CharField(max_length=500)
    expiry_date = models.DateTimeField()
    used = models.BooleanField(default=False)
