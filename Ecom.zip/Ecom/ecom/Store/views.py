from django.shortcuts import render, redirect, HttpResponseRedirect
from django.shortcuts import get_object_or_404
from .models import Product, Store, ResetToken, Review, Order, StoreSerializer
from .models import ProductSerializer, ReviewSerializer
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.urls import reverse
from django.db import transaction
from django.contrib.auth.models import Group, Permission
from django.contrib.auth import get_user_model
from .forms import SignUpForm, StoreForm
from Cart.cart import Cart
from django.core.mail import EmailMessage
import secrets
from datetime import datetime, timedelta
from hashlib import sha1
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.decorators import renderer_classes, authentication_classes
from rest_framework.decorators import permission_classes
from rest_framework_xml.renderers import XMLRenderer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated as IsAuthentication
from .functions.tweet import Tweet
from django.contrib.auth import get_user
from django.contrib.auth.models import AnonymousUser

User = get_user_model()


def store_summary(request):
    """View to show store page"""
    stores = Store.objects.all()
    return render(request, "store_summary.html", {'stores': stores})


def store(request, store_name):
    # Replace hyphens with spaces in store_name for better readability
    store_name = store_name.replace('-', ' ')
    try:
        store = Store.objects.get(name=store_name)
        products = Product.objects.filter(store=store)
        return render(request, "store.html", {'store': store,
                                              'products': products})
    except Store.DoesNotExist:
        messages.error(request, "Store not found.")
        return redirect('home')


@login_required
@permission_required("Store.create_store", login_url="/login/")
def vendor_dashboard(request):
    # Show vendor's stores and products
    stores = Store.objects.filter(owner=request.user)
    return render(request, "vendor_dashboard.html", {'stores': stores})


@login_required
@permission_required("Store.checkout", login_url="/login/")
def customer_home(request):
    # Show all products to the customer
    products = Product.objects.all()
    return render(request, "customer_home.html", {'products': products})


@api_view(['GET'])
@renderer_classes((XMLRenderer,))
@permission_required("Store.create_store", login_url="/login/")
def view_stores(request):
    """View function to view different stores"""
    if request.method == "GET":
        stores = Store.objects.all()
        serializer = StoreSerializer(stores, many=True)
        return Response(data=serializer.data)


@api_view(['POST'])
@authentication_classes([BasicAuthentication])
@permission_classes([IsAuthentication])
@permission_required("Store.create_store", login_url="/login/")
def add_store(request):
    """View function for users to add stores via api"""
    if request.method == "POST":
        if request.user.id == request.data['vendor']:
            serializer = StoreSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return JsonResponse(data=serializer.data,
                                    status=status.HTTP_201_CREATED)
            return JsonResponse(serializer.errors,
                                status=status.HTTP_400_BAD_REQUEST)
        return JsonResponse({'ID mismatch':
                             'User ID and store ID not matching'},
                            status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@authentication_classes([BasicAuthentication])
@permission_classes([IsAuthentication])
@permission_required("Store.create_store", login_url="/login/")
def add_product(request):
    """View function for users to add products via api"""
    if request.method == "POST":
        if request.user.id == request.data['vendor']:
            serializer = ProductSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return JsonResponse(data=serializer.data,
                                    status=status.HTTP_201_CREATED)
            return JsonResponse(serializer.errors,
                                status=status.HTTP_400_BAD_REQUEST)
        return JsonResponse({'ID mismatch':
                             'User ID and store ID not matching'},
                            status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_required("Store.create_store", raise_exception=True)
def view_products(request):
    """View funtion to view different products"""
    if request.method == "GET":
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return JsonResponse(data=serializer.data, safe=False)


def create_store(request):
    """View to create a store"""
    if request.method == 'POST':
        form = StoreForm(request.POST)
        if form.is_valid():
            user = get_user(request)
            print("Session key:", request.session.session_key)
            print("User object:", user)
            print("Is authenticated:", user.is_authenticated)
            print("Cookies:", request.COOKIES)

            if isinstance(user, AnonymousUser) or not user.is_authenticated:
                messages.error(request, "You must be logged in to create a store.")
                return redirect('login')

            new_store_tweet = "A new store has been created."
            Tweet().make_tweet({'text': new_store_tweet})

            messages.success(request, "Store created successfully.")
            return redirect('store_summary')
    else:
        form = StoreForm()
    print("Request user:", request.user)
    print("Authenticated:", request.user.is_authenticated)
    return render(request, "create_store.html", {'form': form})


@permission_required("Store.update_store", raise_exception=True)
def update_store(request, store_id):
    """View to update store details"""
    # Check method
    if request.method == 'POST':
        store_id = request.POST.get('store_id')
        name = request.POST.get('name')
        location = request.POST.get('location')
        # Get the store or raise a 404 error if not found
        store = get_object_or_404(Store, id=store_id)
        # Update the store details
        store.name = name
        store.location = location
        store.save()
        messages.success(request, "Store updated successfully.")
        return redirect('store_summary')
    return render(request, "update_store.html")


@permission_required("Store.delete_store", raise_exception=True)
def delete_store(request, store_id):
    """View to delete a store"""
    # Check method
    if request.method == 'POST':
        store_id = request.POST.get('store_id')
        # Get the store or raise a 404 error if not found
        store = get_object_or_404(Store, id=store_id)
        # Delete the store
        store.delete()
        messages.success(request, "Store deleted successfully.")
        return redirect('store_summary')


def product(request, pk):
    """View to add product"""
    product = Product.objects.get(id=pk)
    return render(request, "product.html", {'product': product})


@permission_required("Store.create_product", raise_exception=True)
def create_product(request):
    """View to create a product"""
    # Check method
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        stock = request.POST.get('stock')
        image = request.FILES.get('image')
        store_id = request.POST.get('store_id')
        # Get the store or raise a 404 error if not found
        store = get_object_or_404(Store, id=store_id)
        # Create the product
        Product.objects.create(name=name, description=description,
                               price=price, stock=stock,
                               image=image, store=store)
        new_prod_tweet = name + " has been added to " + store.name + "."
        + description
        tweet = {'text': new_prod_tweet}
        Tweet().make_tweet(tweet)
        messages.success("Product created succesfully")
        return redirect("store", store.name)
    return render(request, "create_product.html")


@permission_required("Store.update_product", raise_exception=True)
def update_product(request, product_id):
    """View to update product details"""
    # Check method
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        stock = request.POST.get('stock')
        image = request.FILES.get('image')
        store_id = request.POST.get('store_id')
        # Get the store or raise a 404 error if not found
        store = get_object_or_404(Store, id=store_id)
        # Get the product or raise a 404 error if not found
        product = get_object_or_404(Product, id=product_id)
        # Update the product details
        product.name = name
        product.description = description
        product.price = price
        product.stock = stock
        if image:
            product.image = image
        product.store = store
        product.save()
        messages.success(request, "Product updated successfully.")
        return redirect("product", product.id)
    return render(request, "update_product.html")


@permission_required("Store.delete_product", raise_exception=True)
def delete_product(request, product_id):
    """View to delete a product"""
    # Check method
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        # Get the product or raise a 404 error if not found
        product = get_object_or_404(Product, id=product_id)
        store_name = product.store.name
        # Delete the product
        product.delete()
        messages.success(request, "Product deleted successfully.")
        return redirect("store", store_name)


def home(request):
    """View to add products to home page"""
    products = Product.objects.all()
    return render(request, "home.html", {'products': products})


def about(request):
    """View to display about page"""
    return render(request, "about.html", {})


def login_user(request):
    """View to login user"""
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            request.session.save()
            print("Logged in user:", user)
            messages.success(request, "You have logged in successfully.")
            if user.groups.filter(name='vendor').exists():
                return redirect('vendor_dashboard')
            else:
                return redirect('customer_home')
        else:
            messages.error(request, "Invalid username or password.")
            return redirect('login')
    else:
        return render(request, "login.html", {})


def logout_user(request):
    """View to logout user"""
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('home')


def register_user(request):
    """View to register a user"""
    form = SignUpForm()
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                user = form.save(commit=False)
                password = form.cleaned_data.get('password1')
                role = form.cleaned_data.get('role')
                user.set_password(password)
                user.save()
                # Assign user to group
                group, _ = Group.objects.get_or_create(name=role)
                if role == "vendor":
                    perms = Permission.objects.filter(codename__in=[
                            'create_store', 'update_store', 'delete_store',
                            'create_product', 'update_product',
                            'delete_product'])
                    group.permissions.set(perms)
                elif role == "customer":
                    perms = Permission.objects.filter(codename__in=[
                        'checkout', 'reviews'])
                    group.permissions.set(perms)
                user.groups.add(group)
            login(request, user)
            messages.success(request, "Registration successful.")
            if role == 'vendor':
                return redirect('vendor_dashboard')
            else:
                return redirect('customer_home')
        else:
            messages.error(request, "Registration failed. "
                           "Please correct the errors below.")
            return render(request, "register.html", {'form': form})
    else:
        return render(request, "register.html", {'form': form})


@permission_required("Store.checkout", raise_exception=True)
def checkout(request):
    """View to checkout and create invoice for items"""
    cart = Cart(request)
    # Get products in the cart
    cart_products = cart.get_products()
    # Get quantities of each product in the cart
    quantities = cart.get_quants
    # Get totals of the products in the cart
    totals = cart.cart_total()
    if request.method == 'POST':
        # Create an order
        order = Order.objects.create(user=request.user, total=totals)
        for product in cart_products:
            # Add products to the order
            order.products.add(product)
        cart.clear()
        messages.success(request, "Order placed successfully!")
        return redirect('home')
    return render(request, 'checkout.html', {
        'cart_products': cart_products,
        'quantities': quantities,
        'totals': totals
    })


def build_email(user, reset_url):
    """View to build an email for resetting the user's password"""
    subject = "Password Reset"
    user_email = user.email
    domain_email = "example@domain.com"
    body = f"Hi {user.username},\nHere is your link to reset your"
    f"password: {reset_url}"
    email = EmailMessage(subject, body, domain_email, [user_email])
    return email


def generate_reset_url(user):
    """View to generate the url for resetting the password"""
    domain = "http://127.0.0.1:8000/"
    app_name = "grabmore"
    url = f"{domain}{app_name}/reset_password/"
    token = str(secrets.token_urlsafe(16))
    expiry_date = datetime.now() + timedelta(minutes=5)
    reset_token = ResetToken.objects.create(user=user,
                                            token=sha1(token.encode())
                                            .hexdigest(),
                                            expiry_date=expiry_date)
    url += f"{reset_token}/"
    return url


def send_password_reset(request):
    """View to send email to reset the user's password"""
    user_email = request.POST.get('email')
    user = User.objects.get(email=user_email)
    url = generate_reset_url(user)
    email = build_email(user, url)
    email.send()
    return HttpResponseRedirect(reverse('ecommerce:login'))


def reset_user_password(request, token):
    """View to reset the user's password"""
    try:
        sha1(token.encode()).hexdigest()
        user_token = ResetToken.objects.get(token=sha1(token.encode())
                                            .hexdigest())
        if user_token.expiry_date.replace(tzinfo=None) < datetime.now():
            user_token.delete()
            request.session['user'] = user_token.user.username
            request.session['token'] = token
    except ResetToken.DoesNotExist:
        user_token = None
    return render(request, 'password_reset.html', {'token':
                                                   user_token})


def reset_password(request):
    """View to complete resetting the user's password"""
    username = request.session['user']
    token = request.session['token']
    password = request.POST.get('password')
    password_conf = request.POST.get('password_conf')
    if password == password_conf:
        change_user_password(username, password)
        ResetToken.objects.get(token=sha1(token.encode()).hexdigest()).delete()
        return HttpResponseRedirect(reverse('ecommerce:login'))
    else:
        return HttpResponseRedirect(reverse('ecommerce:password_reset'))


def reviews(request):
    """View to write reviews for products"""
    # Check if user is authenticated
    if not request.user.is_authenticated:
        messages.error(request, "You must be logged in to view your reviews.")
        return redirect('login')
    else:
        user = request.user
        user_reviews = Review.objects.filter(user=user)
        verified_reviews = []
        unverified_reviews = []
        for review in user_reviews:
            # Check if user has ordered the product
            has_order = Order.objects.filter(user=user,
                                             products=review.product).exists()
            if has_order:
                verified_reviews.append(review)
            else:
                unverified_reviews.append(review)
    return render(request, "review.html", {
        'verified_reviews': verified_reviews,
        'unverified_reviews': unverified_reviews,
    })


@api_view(['GET'])
@permission_required("Store.reviews", login_url="/login/")
def review_list(request):
    """View to get list of reviews or create a new review"""
    if request.method == 'GET':
        reviews = Review.objects.all()
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data)


api_view(['GET'])
@permission_required("Store.reviews", login_url="/login/")
def review_detail(request, pk):
    """View to get, update or delete a review"""
    try:
        review = Review.objects.get(pk=pk)
    except Review.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = ReviewSerializer(review)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ReviewSerializer(review, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        review.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
