# store/management/commands/init_roles.py
from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from Store.models import Store, Product


class Command(BaseCommand):
    help = "Initialize user roles and assign permissions"

    def handle(self, *args, **kwargs):
        roles = {
            'Vendor': ['create_store', 'update_store', 'delete_store',
                       'create_product', 'update_product', 'delete_product'],
            'Customer': ['checkout', 'reviews'],
        }

        for role, perms in roles.items():
            group, created = Group.objects.get_or_create(name=role)
            permissions = Permission.objects.filter(codename__in=perms)
            group.permissions.set(permissions)
            group.save()
            self.stdout.write(self.style.SUCCESS(
                f"{'Created' if created else 'Updated'} group '{role}' with {len(perms)} permissions."
            ))
