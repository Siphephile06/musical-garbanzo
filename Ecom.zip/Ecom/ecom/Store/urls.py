from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
     path('', views.home, name='home'),
     path('about/', views.about, name='about'),
     path('login/', views.login_user, name='login'),
     path('logout/', views.logout_user, name='logout'),
     path('register/', views.register_user, name='register'),
     path('products/<int:pk>/', views.product, name='product'),
     path('stores/<str:store_name>/', views.store, name='store'),
     path('stores/', views.store_summary, name='store_summary'),
     path('checkout/', views.checkout, name='checkout'),
     path('reset_password/', views.send_password_reset, name='reset_password'),
     path('reset_password/<str:token>/', views.reset_user_password,
          name='password_reset'),
     path('build_email/', views.build_email, name='build_email'),
     path('generate_reset_url/<str:token>/', views.generate_reset_url,
          name='generate_reset_url'),
     path('send_password_reset/', views.send_password_reset,
          name='send_password_reset'),
     path('reviews/', views.reviews, name='reviews'),
     path('create_store/', views.create_store, name='create_store'),
     path('update_store/<int:store_id>', views.update_store,
          name='update_store'),
     path('delete_store/<int:store_id>', views.delete_store,
          name='delete_store'),
     path('create_product/', views.create_product, name='create_product'),
     path('update_product/<int:product_id>', views.create_product,
          name='update_product'),
     path('delete_product/<int:product_id>', views.delete_product,
          name='delete_product'),
     path('customer/', views.customer_home, name='customer_home'),
     path('vendor/', views.vendor_dashboard, name='vendor_dashboard'),
     path('get/stores', views.view_stores, name='view_stores'),
     path('get/products', views.view_products, name='view_products'),
     path('api/reviews/', views.review_list, name='review_list'),
     path('api/reviews/<int:pk>/', views.review_detail, name='review_detail'),
]

# Serving static and media files during development
urlpatterns += static(settings.STATIC_URL,
                      document_root=settings.STATICFILES_DIRS[0])
urlpatterns += static(settings.MEDIA_URL,
                      document_root=settings.MEDIA_ROOT)
