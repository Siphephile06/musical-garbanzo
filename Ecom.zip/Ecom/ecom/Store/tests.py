from django.test import TestCase
from .models import Store, User, Product, Review, ResetToken
from django.urls import reverse


class UserModelTest(TestCase):
    def setUp(self):
        # Create a test user
        self.username = 'testuser'
        self.email = 'test@gmail.com'
        self.password = 'testpassword'
        self.group = 'customer'

        self.user = User.objects.create(
            username=self.username,
            email=self.email,
            password=self.password,
            group=self.group
        )

    def test_user_creation(self):
        self.assertEqual(self.user.username, 'testuser')
        self.assertEqual(self.user.password, 'testpassword')
        self.assertEqual(self.user.email, 'test@gmail.com')
        self.assertEqual(self.user.group, 'customer')


class StoreModelTest(TestCase):
    def setUp(self):
        self.username = 'testuser'
        self.email = 'test@gmail.com'
        self.password = 'testpassword'
        self.group = 'customer'
        self.user = User.objects.create(
            username=self.username,
            email=self.email,
            password=self.password,
            group=self.group
        )
        self.name = "Test store"
        self.location = "Test location"
        self.owner = self.user
        self.store = Store.objects.create(
            name=self.name,
            location=self.location,
            owner=self.owner
        )

    def test_store_creation(self):
        self.assertEqual(self.store.name, 'Test store')
        self.assertEqual(self.store.location, 'Test location')
        self.assertEqual(self.store.owner, self.user)


class StoreViewsTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(
            username='testuser',
            email='test@gmail.com',
            password='testpassword',
            group='customer'
        )
        self.store = Store.objects.create(
            name='Test store',
            location='Test location',
            owner=self.user
        )

    def test_create_store_view(self):
        url = reverse('create_store')
        response = self.client.post(url, {
            'name': 'New Store',
            'location': 'New Location',
            'owner': self.user.id
        })
        self.assertEqual(response.status_code, 302)

    def test_update_store_view(self):
        response = self.client.post(reverse('update_store',
                                            args=[self.store.pk]))
        self.assertEqual(response.status_code, 302)

    def test_delete_store_view(self):
        response = self.client.post(reverse('delete_store',
                                            args=[self.store.pk]))
        self.assertEqual(response.status_code, 302)


class ProductModelTest(TestCase):
    def setUp(self):
        self.store = Store.objects.create(
            name='Test store',
            location='Test location'
        )
        self.name = "Test Product"
        self.description = "Test Description"
        self.price = 10.99
        self.stock = 100
        self.product = Product.objects.create(
            name=self.name,
            description=self.description,
            price=self.price,
            stock=self.stock,
            store=self.store,
        )

    def test_product_creation(self):
        self.assertEqual(self.product.name, 'Test Product')
        self.assertEqual(self.product.description, 'Test Description')
        self.assertEqual(self.product.price, 10.99)
        self.assertEqual(self.product.stock, 100)
        self.assertEqual(self.product.store, self.store)


class ProductViewsTest(TestCase):
    def setUp(self):
        # Create a test user
        self.user = User.objects.create(
            username='testuser',
            email='test@gmail.com',
            password='testpassword',
            group='customer'
        )
        # Create a test store
        self.store = Store.objects.create(
            name='Test store',
            location='Test location',
            owner=self.user
        )
        # Create a test product
        self.product = Product.objects.create(
            name='Test Product',
            description='Test Description',
            price=10.99,
            stock=100,
            store=self.store
        )

    def test_create_product_view(self):
        url = reverse('create_product')
        response = self.client.post(url, {
            'name': 'New Product',
            'description': 'New Description',
            'price': 20.00,
            'stock': 50,
            'store': self.store.id
        })
        self.assertEqual(response.status_code, 302)

    def test_update_product_view(self):
        response = self.client.post(reverse('update_product',
                                            args=[self.product.pk]))
        self.assertEqual(response.status_code, 302)

    def test_delete_product_view(self):
        response = self.client.post(reverse('delete_product',
                                            args=[self.product.pk]))
        self.assertEqual(response.status_code, 302)


class AuthViewsTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(
            username='testuser',
            email='test@gmail.com',
            password='testpassword',
            group='customer'
        )

    def create_sample_user(self):
        return User.objects.create(
            username='sampleuser',
            email='sample@gmail.com',
            password='samplepassword',
            group='customer'
        )

    def test_register_user_view(self):
        url = reverse('register')
        response = self.client.post(url, {
            'username': 'newuser',
            'email': 'new@gmail.com',
            'password': 'newpassword',
            'group': 'customer'
            })
        self.assertEqual(response.status_code, 302)

    def test_login_user_view(self):
        url = reverse('login')
        response = self.client.post(url, {
            'username': 'testuser',
            'password': 'testpassword'
        })
        self.assertEqual(response.status_code, 302)

    def test_logout_user_view(self):
        self.client.login(username='testuser', password='testpassword')
        url = reverse('logout')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)


class ReviewsModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(
            username='testuser',
            email='test@gmail.com',
            password='testpassword',
            group='customer'
        )
        self.store = Store.objects.create(
            name='Test store',
            location='Test location',
            owner=self.user
        )
        self.product = Product.objects.create(
            name='Test Product',
            description='Test Description',
            price=10.99,
            stock=100,
            store=self.store
        )
        self.review = Review.objects.create(
            user=self.user,
            product=self.product,
            rating=4,
            comment='Great product!'
        )

    def test_review_creation(self):
        self.assertEqual(self.review.user, self.user)
        self.assertEqual(self.review.product, self.product)
        self.assertEqual(self.review.rating, 4)
        self.assertEqual(self.review.comment, 'Great product!')


class ReviewsViewsTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(
            username='testuser',
            email='test@gmail.com',
            password='testpassword',
            group='customer'
        )
        self.store = Store.objects.create(
            name='Test store',
            location='Test location',
            owner=self.user
        )
        self.product = Product.objects.create(
            name='Test Product',
            description='Test Description',
            price=10.99,
            stock=100,
            store=self.store
        )
        self.review = Review.objects.create(
            user=self.user,
            product=self.product,
            rating=4,
            comment='Great product!'
        )

    def test_reviews_view(self):
        url = reverse('reviews')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Great product!')


class ResetTokenModelTest(TestCase):
    def setUp(self):
        self.reset_token = ResetToken.objects.create(
            user='testuser',
            token='resettoken123',
            expiry_date='2024-12-31 23:59:59',
            used=False
        )

    def test_reset_token_creation(self):
        self.assertEqual(self.reset_token.user, 'testuser')
        self.assertEqual(self.reset_token.token, 'resettoken123')
        self.assertEqual(self.reset_token.used, False)
        self.assertEqual(str(self.reset_token.expiry_date), '2024-12-31 23:59'
                         ':59')
