from .cart import Cart


def cart(request):
    """
    This context processor adds the cart to the context so it can be accessed
    in templates.
    """
    return {'cart': Cart(request)}
