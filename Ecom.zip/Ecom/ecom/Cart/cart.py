from Store.models import Product


class Cart():
    def __init__(self, request):
        self.session = request.session

        # get current session key for cart
        cart = self.session.get('session_key')

        # if it's not there create a session key
        if 'session_key' not in request.session:
            cart = self.session['session_key'] = {}
            request.session.clear()

        # Make sure cart is available on all pages
        self.cart = cart

    def add(self, product, quantity):
        """Add a product to the cart."""
        product_id = str(product.id)
        product_quantity = int(quantity)
        if product_id in self.cart:
            pass
        else:
            self.cart[product_id] = int(product_quantity)

        self.session.modified = True

    def __len__(self):
        """Return the number of items in the cart."""
        return len(self.cart)

    def get_products(self):
        """Return the products in the cart."""
        product_ids = self.cart.keys()
        products = Product.objects.filter(id__in=product_ids)
        return products

    def get_quants(self):
        """ Return the quantities of products in the cart."""
        quantities = self.cart
        return quantities

    def update(self, product, quantity):
        """ Return the updated cart"""
        product_id = str(product)
        product_quantity = int(quantity)
        # Get cart
        ourcart = self.cart
        # Update cart
        ourcart[product_id] = product_quantity
        # Update session
        self.session.modified = True

        cart = self.cart
        return cart

    def delete(self, product):
        """ Return the deleted cart"""
        product_id = str(product)
        # Delete from the dictionary/cart
        if product_id in self.cart:
            del self.cart[product_id]

        self.session.modified = True

    def cart_total(self):
        # Get product IDs
        product_ids = self.cart.keys()
        # Look up those products in our product database model
        products = Product.objects.filter(id__in=product_ids)
        # Get quantities
        quantities = self.cart
        # Start counting at 0
        total = 0
        for key, value in quantities.items():
            # Convert key string into int so we can do math
            key = int(key)
            for product in products:
                if product.id == key:
                    total = total + (product.price * value)
        return total
