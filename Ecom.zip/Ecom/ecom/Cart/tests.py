from django.test import TestCase

class CartViewsTest(TestCase):
    def setUp(self):
        
