from django.shortcuts import render, get_object_or_404
from .cart import Cart
from Store.models import Product
from django.http import JsonResponse


def cart_summary(request):
    """View to display the cart summary.
    This view will render the cart summary template.
    """
    cart = Cart(request)
    cart_products = cart.get_products()
    quantities = cart.get_quants
    totals = cart.cart_total()
    return render(request, "cart_summary.html", {
                                                'cart_products': cart_products,
                                                'quantities': quantities,
                                                'totals': totals})


def add_to_cart(request):
    """View to handle adding items to the cart.
    This view will render the add to cart template.
    """
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        product_id = int(request.POST.get('product_id'))
        product_quantity = int(request.POST.get('product_quantity'))
        product = get_object_or_404(Product, id=product_id)
        # Save to session
        cart.add(product=product, quantity=product_quantity)

        # Get cart quantity
        cart_quantity = cart.__len__()

        return JsonResponse({'quantity': cart_quantity,
                             })
    return render(request, "add_to_cart.html", {})


def cart_delete(request):
    """ View to delete product from cart."""
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        # Get Stuff
        product_id = int(request.POST.get('product.id'))

        # Call delete function in cart
        cart.delete(product=product_id)
        response = JsonResponse({'product': product_id})
        return response
    return render(request, "cart_delete.html", {})


def cart_update(request):
    """ View to update the cart """
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        # Get product
        product_id = int(request.POST.get('product_id'))
        # Get product quantity
        product_quantity = int(request.POST.get('product_quantity'))
        # Update the cart
        cart.update(product=product_id, quantity=product_quantity)
        response = JsonResponse({'quantity': product_quantity})
        return response
    return render(request, "cart_update.html", {})
